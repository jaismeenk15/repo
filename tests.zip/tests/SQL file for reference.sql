
create table verizon_cust
(
  cust_id number(6) primary key,
  password varchar(8) not null,
  cust_name varchar(20) not null,
  mob_datacard_no number(10) unique not null,
  bill_month varchar(15),
  bill_amount_due number(10,2)  
);

insert into VERIZON_CUST (CUST_ID,PASSWORD,CUST_NAME,MOB_DATACARD_NO,BILL_MONTH,BILL_AMOUNT_DUE)
values (1,'pass1','John',9870986756,'July',2000);
insert into VERIZON_CUST (CUST_ID,PASSWORD,CUST_NAME,MOB_DATACARD_NO,BILL_MONTH,BILL_AMOUNT_DUE)
values (2,'pass2','Jane',4567893546,'July',4400);
insert into VERIZON_CUST (CUST_ID,PASSWORD,CUST_NAME,MOB_DATACARD_NO,BILL_MONTH,BILL_AMOUNT_DUE) 
values (3,'pass3','Vicky',3425678123,'July',3000);
insert into VERIZON_CUST (CUST_ID,PASSWORD,CUST_NAME,MOB_DATACARD_NO,BILL_MONTH,BILL_AMOUNT_DUE)
values (4,'pass4','Rex',6754890345,'July',3050);
insert into VERIZON_CUST (CUST_ID,PASSWORD,CUST_NAME,MOB_DATACARD_NO,BILL_MONTH,BILL_AMOUNT_DUE) 
values (5,'pass5','Rita',6573849367,'July',2000);


create table payment_details
(
invoice_no number(10) primary key,
mob_datacard_no number(10) references verizon_cust(mob_datacard_no),
amt_paid number(10,2),
payment_date date,
payment_mode varchar(2) check(payment_mode in('CC','DC')),
debit_credit_card_no varchar(16)
);

create sequence invoice_no_seq
start with 1
increment by 1
maxvalue 10000


