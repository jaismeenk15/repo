package com;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
// step 3
@Controller		//spring makes a bean for this class using controller annotation
public class MyController {
	
	@RequestMapping("/welcome")		//this calls the method
		String handleRequest(){
			System.out.println("Processing Request");
			return "result";	//this method will send return the string result,
			//which will be the name of the jsp file(result.jsp)
			//this string goes from this view controller to the view
		}
}
