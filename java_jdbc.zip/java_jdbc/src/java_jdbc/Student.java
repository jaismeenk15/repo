package java_jdbc;

public class Student implements Comparable<Student>{
	int studentId;
	String name;
	int age;
	public Student(int studentId, String name, int age) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.age = age;
	}
		@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", age="
				+ age + "]\n";
	}
		/*	@Override
	public int hashCode()
	{
		return studentId%10;
	}
	@Override
	public boolean equals(Object o){	//o is the object sent as parameter
		if(this.studentId==( (Student)o ).studentId)		//compares with current object
			return true;
		else
			return false;
	}
	@Override*/
	public int compareTo(Student o) {
		if(this.studentId>o.studentId)
			return 1;
		else if(this.studentId<o.studentId)
			return -1;
		else return 0;
	}
}
