package java_jdbc;

public class StaticDemo {
	 static{
		 System.out.println("main static");
	 }
	 public static void main(String[] args) {
		 System.out.println("starting main fundtion");
		 Sample s=new Sample();
	 }
}

class Sample{
	static{
		System.out.println("sample class loading");
	}
}