package java_jdbc;

import java.util.TreeSet;
import java.util.Set;

public class TreeCollections {
	 public static void main(String[] args) {
		 Student s1=new Student(101,"harish",22);
		 Student s2=new Student(102,"hari",23);
		 Student s3=new Student(103,"raghav",28);
		 Student s4=new Student(102,"hari",23);
	 
		// System.out.println(s2.equals(s4));
		// System.out.println(s3.equals(s1));
//		 Set<Student> studSet=new TreeSet<Student>(new AgeComparator());
		 Set<Student> studSet=new TreeSet<Student>();
		 studSet.add(s1);
		 studSet.add(s2);
		 studSet.add(s3);
		 studSet.add(s4);
		 System.out.println(studSet);
	 }
}
