package java_jdbc;

import java.util.Comparator;

public class AgeComparator implements Comparator<Student> {

	/*@Override
	public int compare(Student s1, Student s2) {
		return s1.name.compareTo(s2.name);
	
	}
*/
	@Override
	public int compare(Student s1, Student s2) {
		if(s1.age>s2.age)
			return 1;
		else if(s1.age<s2.age)
			return -1;
		else return 0;
	}
	/*
	@Override
	public int compare(Student s1, Student s2) {
		if(s1.studentId>s2.studentId)
			return 1;
		else if(s1.studentId<s2.studentId)
			return -1;
		else return 0;
	}*/
}
