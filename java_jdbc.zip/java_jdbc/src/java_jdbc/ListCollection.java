package java_jdbc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class ListCollection {

	public static void main(String[] args) {
		 Student s1=new Student(101,"harish",22);
		 Student s2=new Student(102,"hari",23);
		 Student s3=new Student(103,"raghav",28);
		 Student s4=new Student(102,"hari",23);
	 
		// System.out.println(s2.equals(s4));
		 //System.out.println(s3.equals(s1));
		 List<Student> studSet=new ArrayList<Student>();
		 studSet.add(s1);
		 studSet.add(s2);
		 studSet.add(s3);
		 studSet.add(s4);
		 System.out.println(studSet);
	 
		 Collections.sort(studSet,new AgeComparator());
		 System.out.println(studSet);
		 
		 Collections.sort(studSet,Collections.reverseOrder(new AgeComparator()));
		 System.out.println(studSet);
		 
		 String s[]={"one","two"};
		 List<String> l=Arrays.asList(s);
		 System.out.println(l);
		 String name[]=(String[])l.toArray();
		 System.out.println(name);
	}

	}

