package bean;

import org.mycompany.Employeee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainProgram2 {

	public static void main(String[] args) {

		ApplicationContext fact=new ClassPathXmlApplicationContext("ApplicationContent2.xml"); 
		//   |  directly gets the xml file without using beans
		Employeee e=(Employeee)fact.getBean("mybean2");
		//type casted, because the output of getBean method is an object
		e.details();
		
		
	}

}
