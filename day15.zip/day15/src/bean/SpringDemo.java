package bean;

public class SpringDemo {

	public static void main(String[] args) {
		Programmer m=new Programmer();
		Manager p=new Manager();
		Company c1=new Company(m);	//Constructor injection
		Company c2=new Company(p);
		c1.setEmployee(p);			//injecting dependency objects using constructor or setter
		//create object and inject dependencies=pulled injection
	//when using spring, no need to declare objects and inject dependencies
	
	}

}

class Company{
	Employee employee;		//loosely coupled
							//can inject both manager or programmer object in employee object into the constructor
	public Company(Employee employee) {		//constructor injection
		super();
		this.employee = employee;
	}
	 void setEmployee(Employee employee){		//setter injection
		 this.employee=employee;
	 }
}

abstract class Employee{}
class Manager extends Employee{}
class Programmer extends Employee{}
