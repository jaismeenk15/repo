package bean;
import org.mycompany.Address;
import org.mycompany.Employeee;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
public class MainProgram {

	public static void main(String[] args) {
		//BeanFactory fact=new XmlBeanFactory(new ClassPathResource("ApplicationContent.xml"));// used when xml file is in a different package or folder
		//BeanFactory fact=new XmlBeanFactory(new FileSystemResource("ApplicationContent.xml"));//--- used when xml file is in root folder(project)
		//bean factory is used to access the spring framework
		//Spring container--
		//1.Bean Factory
		//2.Application Cont000ext--- this has the configuration for the spring  
		//3. Web application context
		ApplicationContext fact=new ClassPathXmlApplicationContext("ApplicationContent3.xml"); 
		Employeee e=(Employeee)fact.getBean("mybean");
		//type casted, because the output of getBean method is an object
		e.details();		
	}

}

