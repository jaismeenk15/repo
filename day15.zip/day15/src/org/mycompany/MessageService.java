package org.mycompany;

interface MessageService {
	void sendMessage( String receiverName, String msg);
}
