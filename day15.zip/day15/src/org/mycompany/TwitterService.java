package org.mycompany;


public class TwitterService implements MessageService{
	@Override
	public void sendMessage( String receiverName, String msg){
		System.out.println("message is: "+msg +"\nTwitter Delivered to: "+ receiverName);
	}
}
