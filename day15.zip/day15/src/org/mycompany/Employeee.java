package org.mycompany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("mybean")			//to scan for annotations
public class Employeee {
	@Value ("contract")	
	String category;
	@Value("22")
		int age;
	    @Autowired		   
	    Address address1;
	    @Autowired
	    Address address2;

	
		public Address getAddress1() {
			return address1;
		}


		public void setAddress1(Address address1) {
			this.address1 = address1;
		}


		public Address getAddress2() {
			return address2;
		}


		public void setAddress2(Address address2) {
			this.address2 = address2;
		}


		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}


		public String getCategory() {
			return category;
		}


		public Employeee() {}


		public void setCategory(String category) {
			this.category = category;
		}
		
		


		public void details(){
			//System.out.println("I'm working for my company");
			System.out.println("I'm a "+category+" Employee and my age is "+age);
			System.out.println("my address is :"+address1.getDoorno()+"  "+address1.getCity());
			System.out.println("my address is :"+address2.getDoorno()+"  "+address2.getCity());
		}


		/*public Employeee(String category, int age) {
			super();
			this.category = category;
			this.age = age;
		}*/
}
