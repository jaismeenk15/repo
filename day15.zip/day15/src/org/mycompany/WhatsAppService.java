package org.mycompany;


public class WhatsAppService implements MessageService{
	@Override
	public void sendMessage( String receiverName, String msg){
		System.out.println("message is: "+msg +"\nWhatsapp Delivered to: "+ receiverName);
	}
}
