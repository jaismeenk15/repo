package testing;

import static org.junit.Assert.assertEquals;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import code.ImaginaryRootException;
import code.Question3;
public class Question3Test {
	Question3 c;
	double expected[]={0,0};
	@Before
	public void init(){
		System.out.println("Begin");
		c=new Question3();
	}
	@Test
	public void test01(){
		double actual[];
		try {
			actual = c.calc(3,-4,10);
			expected[0]=0.0;
			expected[1]=0.0;
			assertEquals(expected[0],actual[0],0.001);
			assertEquals(expected[1],actual[1],0.001);
		} catch (ImaginaryRootException e) {
			System.out.println("IMAGINARY ROOT");
		}
		
	}
	@Test
	public void test02(){
		double actual[];
		try {
			actual = c.calc(2,6,4);
			expected[0]=-1.0;
			expected[1]=-2.0;
			assertEquals(expected[0],actual[0],0.001);
			assertEquals(expected[1],actual[1],0.001);
		} catch (ImaginaryRootException e) {
			System.out.println("IMAGINARY ROOT");
		}
		
	}
	@Test
	public void test03(){
		double actual[];
		try {
			actual = c.calc(1,-2,1);
			expected[0]=1.0;
			expected[1]=1.0;
			assertEquals(expected[0],actual[0],0.001);
			assertEquals(expected[1],actual[1],0.001);
		} catch (ImaginaryRootException e) {
			System.out.println("IMAGINARY ROOT");
		}
		
	}
	
	@After
	public void finish(){
		System.out.println("end");
	}
}
