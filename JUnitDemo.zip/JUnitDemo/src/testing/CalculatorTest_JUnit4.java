package testing;
import code.Calculator;
//import junit.framework.TestCase;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class CalculatorTest_JUnit4 {
	
		Calculator c;
		@Before
		public void init(){
			System.out.println("Initializing test enironment");
			c=new Calculator();
		}
		@Test
		public void addTest01(){
			int input1=20;
			int input2=10;
			int expectedOutput=2;
			int actual=c.div(input1, input2);
			assertEquals(expectedOutput,actual);
		}
		@Test
		public void divTest02(){
			int input1=25;
			int input2=12;
			double expectedOutput=2.08;
			double actual=c.divide(input1, input2);
			System.out.println(actual);
			//assertEquals(expectedOutput,actual);
			assertEquals(expectedOutput,actual,0.004);
		}
		@Test(expected=ArithmeticException.class)
		public void testUTC03(){
			int input1=25;
			int input2=0;
			c.div(input1, input2);
			//int expectedOutput=2;
//			int actual=
			/*
			try{
				
				fail("Arithmetic Exception expected");
			}catch(ArithmeticException ae){
				assertEquals(1,1);
				//assertTrue(true);------- for functions returning boolean values
			}
				*/
			//assertEquals(expectedOutput,actual);
		}
		
		@Test(timeout=1000)
		public void execTime(){
			c.infinite();
		}
		
		@After
		public void cleanUp(){
			System.out.println("clearing test environment");
		}
	}
