package testing;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import code.Calculator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)

public class CalcDiffTest {
	Calculator c;
	int input1;
	int input2;
	int expected;
	public CalcDiffTest(int input1, int input2, int expected) {
		super();
		this.input1 = input1;
		this.input2 = input2;
		this.expected = expected;
	}
	@Parameterized.Parameters
	public static Collection myParam(){		//collection is the return type
		return Arrays.asList(
				new Object[][]{
				{10,5,5},
				{-10,-5,-5},		// these values are used in constructor and computation is done for these values
				{10,-5,15}				
		}
				);
	}
	@Before
	public void init(){
		c=new Calculator();
	}
	@Test
	public void addTest01(){
		int actual=c.sub(input1, input2);
		assertEquals(expected,actual);
	}
}
