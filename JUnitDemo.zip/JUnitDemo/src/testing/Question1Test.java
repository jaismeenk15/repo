package testing;

import static org.junit.Assert.*;
import code.Question1;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


	public class Question1Test {
		Question1 q;
		
		@Before
		public void init(){
			q=new Question1();
		}
		@Test
		public void test01(){
			int[] input={4,7,8,2,9};
			int expected=9;
			int actual=Question1.find_large(input);
			assertEquals(expected,actual);
		}
		
		@Test
		public void test02(){
			int[] input={-9,-4,-2,-1};
			int expected=-1;
			int actual=q.find_large(input);
			assertEquals(expected,actual);
		}
		
		@Test
		public void test03(){
			int[] input={4,-7,-8,2,-9};
			int expected=4;
			int actual=Question1.find_large(input);
			assertEquals(expected,actual);
		}
		@After
		public void finish(){
			System.out.println("End");
		}
	
	}

