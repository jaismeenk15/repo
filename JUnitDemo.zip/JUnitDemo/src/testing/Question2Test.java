package testing;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import code.Question2;
public class Question2Test {

	Question2 q;
	
	@Before
	public void init(){
		System.out.println("Begin");
	}
	@Test
	public void test01(){
		int input[]={9,4,7,3,6,2,1,8,10,21}; //even number of elements-median=(6+7)/2
		q=new Question2(input);
		int expected=6;
		int actual=q.calc();
		assertEquals(expected,actual);
	}
	@Test
	public void test02(){
		int input[]={9,4,7,3,6,2,1,8,21};
		q=new Question2(input);
		int expected=6;
		int actual=q.calc();
		assertEquals(expected,actual);
	}
	@Test(timeout=1)
	public void test03(){
		int input[]={9,4,7,3,6,2,1,8,10,9,4,6,3,6,2,1,8,10,11,11};
		q=new Question2(input);
		int expected=6;
		int actual=q.calc();
		assertEquals(expected,actual);
	}
	
	@After
	public void finish(){
		
	}
}
