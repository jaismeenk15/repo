package code;

public class Calculator {
	public int add(int a,int b){
		return a+b;
	}
	
	public double divide(double a,double b){
		return a/b;
	}
	
	public int div(int a,int b){
		return a/b;
	}
	public void infinite(){
		while(true){
			
		}
	}
	public int sub(int a,int b){
		return a-b;
	}
}
