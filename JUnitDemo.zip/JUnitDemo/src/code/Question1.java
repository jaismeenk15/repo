package code;

public class Question1 {
	public static int find_large(int arr[]){  
        int lar=0;  
        for(int i=1;i<arr.length;i++){  
            if(lar<arr[i])  
                lar=arr[i];  
        }  
        return lar;  
 } 
}
