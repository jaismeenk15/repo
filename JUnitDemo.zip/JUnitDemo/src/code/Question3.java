package code;

public class Question3 {
	int a;
	int b;
	int c;
	double arr[]={0,0};
	public double[] calc(int a, int b, int c) throws ImaginaryRootException{
		
		double temp = (b * b - 4 * a * c);
		 if (temp >= 0) {
	            double temp1 = Math.sqrt(b * b - 4 * a * c);
	            double root1 = (double)(-b + temp1) / (2 * a);
	            double root2 = (double)(-b - temp1) / (2 * a);
	            arr[0] = root1;
	            arr[1] = root2;
	            return arr;
	        } else {
	            ImaginaryRootException i=new ImaginaryRootException();
	            throw i;
	        }

	}
}

