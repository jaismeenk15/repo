package code;

import java.util.Arrays;

public class Question2 {
	int arr[];
	int arr2[];
	public Question2(int[] arr) {
		super();
		this.arr = arr;
	}

	/*Scanner s=new Scanner(System.in);
	public void initVal(){
		System.out.println("Enter number of elements");
		int n=s.nextInt();
		for(int i=0;i<n;i++){
		System.out.println("Enter element "+i);
		arr[i]=s.nextInt();
		}
	}
	*/
	public void rotate(){
		for(int i=0;i<arr.length;i++){
			if(i==(arr.length-1))
				arr2[0]=arr[i];
			else
				arr2[i]=arr[i];
			System.out.println(arr2[i]);
		}
	}
	
	public int calc(){
		Arrays.sort(arr);
		int middle = arr.length/2;
		int medianValue = 0; //declare variable 
		if (arr.length%2 == 1) 
		    medianValue = arr[middle];
		else
		   medianValue = (arr[middle-1] + arr[middle]) / 2;
		
		return medianValue;
	}
}
