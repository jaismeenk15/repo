package code;

public class ImaginaryRootException extends Exception {
	
	    public ImaginaryRootException() {
	    
	     System.out.println("Imaginary Root Exception Encountered");}
	}

