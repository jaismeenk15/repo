package jdbcExpl;
//for example3
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import oracle.jdbc.OracleDriver;

public class EmployeeOracleDAO {
	
	void addEmployee(Employees e){
		
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement ps=null;
		//ResultSet rs=null;
		String query="INSERT INTO EMPLOYEE VALUES(?,?,?)";
		try {
			Driver d=new OracleDriver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,"hr","manager");
			ps=con.prepareStatement(query);
			ps.setString(1, e.firstName);
			ps.setString(2, e.lastName);
			ps.setInt(3, e.sal);
			int rows=ps.executeUpdate();// gives no. of rows effected or updated
			System.out.println("no. of rows effected: "+rows);
			con.commit();
		} catch (SQLException ex) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ex.printStackTrace();
		}finally{
			try {
				ps.close();
				con.close();
			} catch (SQLException xe) {
				// TODO Auto-generated catch block
				xe.printStackTrace();
			}
		}
	}
	
	void deleteEmployee(int empid){
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement ps=null;
		//ResultSet rs=null;
		String query="DELETE FROM EMPLOYEES WHERE EMPLOYEE_ID=?";
		try {
			Driver d=new OracleDriver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,"hr","manager");
			ps=con.prepareStatement(query);
			ps.setInt(1, empid);
			int rows=ps.executeUpdate();
			// gives no. of rows effected or updated
			System.out.println("no. of rows effected: "+rows);
			con.commit();
		} catch (SQLException ex) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ex.printStackTrace();
		}finally{
			try {
				ps.close();
				con.close();
			} catch (SQLException xe) {
				// TODO Auto-generated catch block
				xe.printStackTrace();
			}
		}
	}
	
	
	void updateEmployee(int empid){
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement ps=null;
		//ResultSet rs=null;
		String query="UPDATE EMPLOYEES SET SALARY=? WHERE EMPLOYEE_ID=?";
		try {
			Driver d=new OracleDriver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,"hr","manager");
			ps=con.prepareStatement(query);
			System.out.println("enter updated salary");
			int sal=new Scanner(System.in).nextInt();
			ps.setInt(1, sal);
			ps.setInt(2, empid);
			int rows=ps.executeUpdate();
			// gives no. of rows effected or updated
			System.out.println("no. of rows effected: "+rows);
			con.commit();
		} catch (SQLException ex) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ex.printStackTrace();
		}finally{
			try {
				ps.close();
				con.close();
			} catch (SQLException xe) {
				// TODO Auto-generated catch block
				xe.printStackTrace();
			}
		}
	}
	
	
	void getEmployeeById(int empid){
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="SELECT FIRST_NAME,LAST_NAME,SALARY FROM EMPLOYEES WHERE EMPLOYEE_ID=?";
		try {
			Driver d=new OracleDriver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,"hr","manager");
			ps=con.prepareStatement(query);
			
			ps.setInt(1, empid);
			rs=ps.executeQuery();
			//int rows=ps.executeUpdate();// gives no. of rows effected or updated
			//System.out.println("no. of rows effected: "+rows);
			//con.commit();
			while(rs.next()){
				String fname=rs.getString("FIRST_NAME");
				String lname=rs.getString("LAST_NAME");
				int salary=rs.getInt("SALARY");
				Employees e= new Employees(fname,lname,salary);
				e.toString();
			}
		} catch (SQLException ex) {
			
			ex.printStackTrace();
		}finally{
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException xe) {
				// TODO Auto-generated catch block
				xe.printStackTrace();
			}
		} 
	}
	
	
	List<Employees> getDetails(int deptid){
	String query="SELECT FIRST_NAME,LAST_NAME,SALARY FROM EMPLOYEES"
			+ " WHERE DEPARTMENT_ID =?";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;	// its a pointer or iterator pointing to a set of objects
	List<Employees> empList=new ArrayList<Employees>();
	try {
		Driver d=new OracleDriver();
		DriverManager.registerDriver(d);
		con=DriverManager.getConnection(url,"hr","manager");
		ps=con.prepareStatement(query);
		ps.setInt(1,deptid); //1 is the index of parameter ie first parameter in place of"?" and next is the variable
		rs=ps.executeQuery();
		
		System.out.println("FIRST_NAME    LAST_NAME      SALARY");
		while(rs.next()){
			String fname=rs.getString("FIRST_NAME");
			String lname=rs.getString("LAST_NAME");
			int salary=rs.getInt("SALARY");
			Employees e= new Employees(fname,lname,salary);
			empList.add(e);
			
		}
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return empList;
	}
	
	List<Employees> getAllDetails(){
		String query="SELECT FIRST_NAME,LAST_NAME,SALARY FROM EMPLOYEES";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;	// its a pointer or iterator pointing to a set of objects
		List<Employees> empList1=new ArrayList<Employees>();
		try {
			Driver d=new OracleDriver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,"hr","manager");
			ps=con.prepareStatement(query);
			//ps.setInt(1,deptid); //1 is the index of parameter ie first parameter in place of"?" and next is the variable
			rs=ps.executeQuery();
			
			System.out.println("FIRST_NAME    LAST_NAME      SALARY");
			while(rs.next()){
				String fname=rs.getString("FIRST_NAME");
				String lname=rs.getString("LAST_NAME");
				int salary=rs.getInt("SALARY");
				Employees e= new Employees(fname,lname,salary);
				empList1.add(e);
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return empList1;
		}
}
