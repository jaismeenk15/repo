package jdbcExpl;
import java.sql.*;

import oracle.jdbc.OracleDriver;
public class example {

	public static void main(String[] args) {
			Connection con=null;
			try {
				Driver d= new OracleDriver();	//create driver object
				DriverManager.registerDriver(d);	//register the driver
				// create the string url
				String url="jdbc:oracle:thin:@localhost:1521:xe";
						//thin--- means type 4
						//no server, operations in local host only
						//1521-- port number for oracle
						//3306- port no. for mysql
				//xe--- service id provided by db admin to communicate with this database
				
				String usern="hr";
				String password="manager";
				//Connect to database
				con=DriverManager.getConnection(url,usern,password);
				if(con!=null)
					System.out.println("connection established");
				else
					System.out.println("connection failed");
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				try {
					con.close();		// close the connection after using db
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
	}

}
