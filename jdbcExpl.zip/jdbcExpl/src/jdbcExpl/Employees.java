package jdbcExpl;

public class Employees {
String firstName;
String lastName;
int sal;
@Override
public String toString() {
	return "Employees [firstName=" + firstName + ", lastName=" + lastName
			+ ", sal=" + sal + "]\n";
}
public Employees(String firstName, String lastName, int sal) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.sal = sal;
};

}
