package jdbcExpl;

public class Question2 {

	public static void main(String[] args) {
		Question2DAO qd=new Question2DAO();
		//qd.createTable();
		//qd.getSingle();
		qd.sortType();
	}

}
