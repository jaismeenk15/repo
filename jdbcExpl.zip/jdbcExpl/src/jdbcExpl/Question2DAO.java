package jdbcExpl;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.util.Scanner;

import oracle.jdbc.OracleDriver;


public class Question2DAO {
	void createTable(){


		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String pass = "manager";
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement ps=null;
		//ResultSet rs=null;
		try{

			Class.forName("oracle.jdbc.OracleDriver");


			conn = DriverManager.getConnection(url,user,pass);

			System.out.println("Creating table in given database...");
			stmt = conn.createStatement();

			String sql = "CREATE TABLE BEATLES " +
					"(YEAR NUMBER, " +
					" SONGS VARCHAR2(30), " +
					" DATE_RELEASE DATE, "+
					" TYPE VARCHAR2(10) " + 
					" )"; 

			stmt.executeUpdate(sql);
			System.out.println("Created table in given database...");
			Scanner s=new Scanner(System.in);
			String query="INSERT INTO BEATLES VALUES(?,?,to_date(?,'dd-mon'),?);";
			ps=conn.prepareStatement(query);
			int rows;
			do{

				System.out.println("Enter year of release, song/album name, date of release and type(ep/lp/single)");
				int year=s.nextInt();
				String song=s.next();
				String date=s.next();
				String type=s.next();
				ps.setInt(1, year);
				ps.setString(2, song);
				ps.setString(3, date);
				ps.setString(4, type);
				System.out.println(query);
				rows=ps.executeUpdate();
			}while(rows!=0);
			conn.commit();
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				ps.close();
				conn.close();
			}catch(SQLException se){

				se.printStackTrace();
			}

		}
	}

void getSingle(){
	String query="SELECT SONG FROM BEATLES"
			+ " WHERE YEAR =1965 and DATE_RELEASE LIKE \'NOV24\' ";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	System.out.println(query);
	try {
		Driver d=new OracleDriver();
		DriverManager.registerDriver(d);
		con=DriverManager.getConnection(url,"hr","manager");
		ps=con.prepareStatement(query);
		rs=ps.executeQuery();
		
		while(rs.next()){
			String list_songs=rs.getString("SONG");
			System.out.println(list_songs);
		}
	
	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		try {
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

void sortType(){
	String query="SELECT SONG FROM BEATLES"
			+ " WHERE TYPE LIKE \'SINGLE\' and TYPE LIKE \'LP\' order by year ";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	System.out.println(query);
	try {
		Driver d=new OracleDriver();
		DriverManager.registerDriver(d);
		con=DriverManager.getConnection(url,"hr","manager");
		ps=con.prepareStatement(query);
		rs=ps.executeQuery();
		
		while(rs.next()){
			String list_songs=rs.getString("SONG");
			System.out.println(list_songs);
		}
	
	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		try {
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
}