package jdbcExpl;


//import java.util.Scanner;


public class Example3 {
	
	public static void main(String[] args) {
		
			//System.out.println("enter department id");
			//int deptid=new Scanner(System.in).nextInt();
			EmployeeOracleDAO eo=new EmployeeOracleDAO();
			System.out.println(eo.getDetails(20));
			//System.out.println(eo.getAllDetails());
			Employees es=new Employees("rohan","sharma",87965);
			eo.addEmployee(es);
			eo.updateEmployee(204);
			//eo.getEmployeeById(204);
	}
}
