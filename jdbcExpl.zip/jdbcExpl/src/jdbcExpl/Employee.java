package jdbcExpl;

public class Employee {
	int empid;
	String fname;
	String lname;
	String email;
	//String hdate;
	String jobid;
	int sal;
	int comm;
	int managerId;
	int deptId;
	public Employee(int empid, String fname, String lname, String email, String jobid, int sal, int comm,
			int managerId, int deptId) {
		super();
		this.empid = empid;
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		//this.hdate = hdate;
		this.jobid = jobid;
		this.sal = sal;
		this.comm = comm;
		this.managerId = managerId;
		this.deptId = deptId;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", fname=" + fname + ", lname="
				+ lname + ", email=" + email  + ", jobid=" + jobid + ", sal=" + sal + ", comm="
				+ comm + ", managerId=" + managerId + ", deptId=" + deptId
				+ "]\n";
	}
}
