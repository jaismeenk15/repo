package jdbcExpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;

public class Procedure {

	public static void main(String[] args) throws Exception {
		//String query="SELECT * FROM EMPLOYEES";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		CallableStatement cs=null;
		Class.forName("oracle.jdbc.OracleDriver");
		con=DriverManager.getConnection(url,"hr","manager");
		cs=con.prepareCall("{call SUM_AB(?,?,?)}");
		cs.setInt(1,7);
		cs.setInt(2, 8);
		cs.registerOutParameter(3, Types.INTEGER);
		cs.execute();
		int result=cs.getInt(3);
		System.out.println(result);
		
	}

}
