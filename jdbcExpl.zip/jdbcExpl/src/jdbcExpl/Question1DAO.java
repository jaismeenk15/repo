package jdbcExpl;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleDriver;

public class Question1DAO {
	void addRecord()
	{
		Driver d=new OracleDriver();
		Connection conn=null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		Scanner s=new Scanner(System.in);
		PreparedStatement ps = null;
	    ResultSet rs;
		try {
            DriverManager.registerDriver(d);
            conn = DriverManager.getConnection(url,"hr", "manager");
            String sql = "CREATE TABLE harrypotter " + "(name VARCHAR(255), "
                    + " house VARCHAR(255), " + " role VARCHAR(255), "
                    + " status VARCHAR(255), " + " dies VARCHAR(255))";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            System.out.println("Created table in given database...");
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null)
                    conn.close();
            } catch (SQLException se) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
	}		      
		void insert(){
			Driver d=new OracleDriver();
			Connection conn=null;
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			Scanner s=new Scanner(System.in);
			PreparedStatement ps = null;
		    ResultSet rs;
		try{
			 DriverManager.registerDriver(d);
	            conn = DriverManager.getConnection(url, "hr", "manager");
	            String sql = "INSERT INTO harrypotter VALUES(?,?,?,?,?)";
	            ps = conn.prepareStatement(sql);
	            System.out.println("Enter Name");
	            ps.setString(1, new Scanner(System.in).next());
	            System.out.println("Enter House");
	            ps.setString(2, new Scanner(System.in).next());
	            System.out.println("Enter Role");
	            ps.setString(3, new Scanner(System.in).next());
	            System.out.println("Enter Status");
	            ps.setString(4, new Scanner(System.in).next());
	            System.out.println("Enter Dies");
	            ps.setString(5, new Scanner(System.in).next());
	            rs = ps.executeQuery();
	            System.out.println("Data Entered");
	        } catch (SQLException se) {
	            se.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (ps != null)
	                    conn.close();
	            } catch (SQLException se) {
	            }
	            try {
	                if (conn != null)
	                    conn.close();
	            } catch (SQLException se) {
	                se.printStackTrace();
	            }
	        }
	}
}
