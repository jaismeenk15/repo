package jdbcExpl;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.OracleDriver;

public class EmployeeOracleDAO2 {

	List<Employee> getAllDetails(){
		String query="SELECT * FROM EMPLOYEES";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;	// its a pointer or iterator pointing to a set of objects
		List<Employee> empList1=new ArrayList<Employee>();
		try {
			Driver d=new OracleDriver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,"hr","manager");
			ps=con.prepareStatement(query);
			//ps.setInt(1,deptid); //1 is the index of parameter ie first parameter in place of"?" and next is the variable
			rs=ps.executeQuery();
			
			//System.out.println("FIRST_NAME    LAST_NAME      SALARY");
			while(rs.next()){
				int eid=rs.getInt(1);
				String fname=rs.getString(2);
				String lname=rs.getString(3);
				String email=rs.getString(4);
				//String hdate=rs.getString(6);
				String jobid=rs.getString(7);
				int salary=rs.getInt(8);
				int comm=rs.getInt(9);
				int mid=rs.getInt(10);
				int did=rs.getInt(11);
				Employee e= new Employee(eid,fname,lname,email,jobid,salary,comm,mid,did);
				
				empList1.add(e);
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return empList1;
		}
}
