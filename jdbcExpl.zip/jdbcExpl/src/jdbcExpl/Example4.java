package jdbcExpl;

public class Example4 {

	public static void main(String[] args) {
		EmployeeOracleDAO2 eo=new EmployeeOracleDAO2();
		System.out.println(eo.getAllDetails());

	}

}
